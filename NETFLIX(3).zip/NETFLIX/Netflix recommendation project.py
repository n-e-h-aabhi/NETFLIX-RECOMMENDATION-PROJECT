#!/usr/bin/env python
# coding: utf-8

# # NETFLIX RECOMMENDATION PROJECT
1. Find out the list of most popular movies and most active users.
2. Create a model that finds the best suited movie for atleast two users.
# In[1]:


#importing libraries
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[7]:


#Load dataset file
df = pd.read_csv(r'C:\Users\Dell\Downloads\combined_data_1.txt.zip',header = None, names = ['Cust_Id', 'Rating'], usecols = [0,1])


# In[8]:


df


# In[9]:


df.shape


# In[10]:


df.isnull().sum()


# In[209]:


df.info()


# In[210]:


# To count the null values resulting in movie count
movie_count=df.isnull().sum()
movie_count=movie_count['Rating']
movie_count


# In[211]:


#To calculate unique values of customer_Id
cust_count= df['Cust_Id'].nunique()
cust_count


# In[212]:


# To get actual no of customers
customer_count=cust_count-movie_count
customer_count


# In[213]:


# To get total no of ratings
rating_count= df['Rating'].count()
rating_count


# In[214]:


# To find how many people have rated the movies 1,2,3,4,5 stars
stars= df.groupby('Rating')['Rating'].agg(['count'])
stars


# In[215]:


ax= stars.plot(kind='barh',legend=False,figsize=(15,10))
plt.title(f"Total pool:{movie_count} Movies,{customer_count} Customers,{rating_count} ratings given",fontsize=20)
plt.grid(True)
plt.show()


# In[216]:


df_nan= pd.DataFrame(pd.isnull(df.Rating))
df_nan


# In[217]:


df_nan=df_nan[df_nan['Rating']==True]
df_nan


# In[218]:


df_nan.shape


# In[219]:


df_nan=df_nan.reset_index()
df_nan


# In[220]:


movie_np=[]
movie_id=1
for i,j in zip(df_nan['index'][1:],df_nan['index'][0:]):
    temp= np.full((1,i-j-1),movie_id)
    movie_np =np.append(movie_np,temp)
    movie_id +=1
temp = np.full((1,24058262-24057834),movie_id)
movie_np = np.append(movie_np,temp)


# In[221]:


movie_np


# In[222]:


df=df[pd.notnull(df['Rating'])]
df['Movie_Id']=movie_np.astype(int)
df['Cust_Id']=df['Cust_Id'].astype(int)
print('Now the dataset will look like')
df


# In[223]:


f=['count','mean']


# In[224]:


dataset_movie_summary=df.groupby('Movie_Id').agg(f)
dataset_movie_summary


# In[225]:


# finding out the no of movies which is seen by less than 70% of users 
dataset_movie_summary=df.groupby('Movie_Id')['Rating'].agg(f)
dataset_movie_summary


# In[226]:


movie_benchmark=round(dataset_movie_summary['count'].quantile(0.7))
movie_benchmark


# In[227]:


drop_movie_list=dataset_movie_summary[dataset_movie_summary['count']<movie_benchmark].index
drop_movie_list


# In[228]:


dataset_cust_summary=df.groupby('Cust_Id').agg(f)
dataset_cust_summary


# In[229]:


#finding out the no of users who are inactive
dataset_cust_summary=df.groupby('Cust_Id')['Rating'].agg(f)
dataset_cust_summary


# In[230]:


cust_benchmark=round(dataset_cust_summary['count'].quantile(0.7))
cust_benchmark


# In[231]:


drop_cust_list=dataset_cust_summary[dataset_cust_summary['count']<cust_benchmark].index
drop_cust_list


# In[232]:


#now removing all the users who are inactive and movies that are less watched by users
print('The original dataframe has:',df.shape,'shape')


# In[233]:


df=df[~df['Movie_Id'].isin(drop_movie_list)]


# In[234]:


df=df[~df['Cust_Id'].isin(drop_cust_list)]


# In[235]:


print('After trimming,the shape is:{}'.format(df.shape))


# In[236]:


df


# In[237]:


df_title =pd.read_csv(r'C:\Users\Dell\Downloads\movie_titles.csv',encoding='ISO-8859-1',
                      header=None,usecols=[0,1,2],names=['Movie_Id','Year','Name'])
df_title.set_index('Movie_Id',inplace=True)


# In[238]:


df_title


# In[242]:


get_ipython().system('pip install scikit-surprise')


# In[243]:


import math 
from surprise import Reader,Dataset,SVD
from surprise.model_selection import cross_validate


# In[244]:


reader=Reader()


# In[246]:


data=Dataset.load_from_df(df[['Cust_Id','Movie_Id','Rating']][:100000],reader)


# In[247]:


svd=SVD()


# In[248]:


cross_validate(svd,data,measures=['RMSE','MAE'],verbose=True)


# In[249]:


df.head()


# We first take the user with cust_id 712664 and try to recommend some movies based on his ratings.

# In[265]:


dataset_712664 =df[(df['Cust_Id']==712664)& (df['Rating']==5)]
dataset_712664


# In[287]:


drop=dataset_712664['Movie_Id']
print(drop)


# In[254]:


user_712664=df_title.copy()
user_712664


# In[278]:


user_712664=df_title.reset_index()
user_712664


# In[279]:


user_712664=user_712664[~user_712664['Movie_Id'].isin(drop_movie_list)]
user_712664


# In[289]:


user_712664=user_712664[~user_712664['Movie_Id'].isin(drop)]
user_712664


# In[290]:


user_712664['Estimate_score']=user_712664['Movie_Id'].apply(lambda x:svd.predict(712664,x).est)
user_712664


# In[291]:


user_712664=user_712664.drop('Movie_Id',axis=1)


# In[292]:


user_712664=user_712664.sort_values('Estimate_score')
print(user_712664)


# In[293]:


user_712664=user_712664.sort_values('Estimate_score',ascending=False)
print(user_712664.head(10))


# In[295]:


df.sort_values('Rating',ascending=False)


# We first take the user with cust_id 2298769 and try to recommend some movies based on his ratings.

# In[296]:


dataset_2298769=df[(df['Cust_Id']==2298769)& (df['Rating']==5)]
dataset_2298769


# In[299]:


drop=dataset_2298769['Movie_Id']
drop=list(drop)
print(drop)


# In[300]:


user_2298769=df_title.copy()
user_2298769


# In[301]:


user_2298769=df_title.reset_index()
user_2298769


# In[302]:


user_2298769=user_2298769[~user_2298769['Movie_Id'].isin(drop_movie_list)]
user_2298769


# In[303]:


user_2298769=user_2298769[~user_2298769['Movie_Id'].isin(drop)]
user_2298769


# In[304]:


user_2298769['Estimate_score']=user_2298769['Movie_Id'].apply(lambda x:svd.predict(2298769,x).est)
user_2298769


# In[305]:


user_2298769=user_2298769.drop('Movie_Id',axis=1)


# In[306]:


user_2298769=user_2298769.sort_values('Estimate_score')
print(user_2298769)


# In[307]:


user_2298769=user_2298769.sort_values('Estimate_score',ascending=False)
print(user_2298769.head(10))


# In[ ]:




